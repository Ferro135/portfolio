# ALUNERI 2.4.0 — Visual System

## Site público
- Novo sistema visual unificado com espaçamento, bordas, raios e superfícies consistentes.
- Header mais limpo e compacto, com melhor leitura ao rolar.
- Hero reorganizado com hierarquia tipográfica mais forte.
- Botões e CTAs padronizados.
- Estatísticas do Hero passam a formar uma superfície única e mais organizada.
- Cards de projetos refinados, com melhor contraste e menos ruído visual.
- Processo, capacidades, princípios, tecnologias e FAQ passam a usar a mesma linguagem de cards.
- Seções com ritmo vertical consistente e separações mais discretas.
- Contato e rodapé refinados.
- Páginas internas passam a seguir a mesma linguagem visual da Home.
- Ajustes dedicados para tablet e mobile.

## Admin
- Sidebar redesenhada com grupos mais legíveis e estado ativo mais claro.
- Topbar mais leve e consistente.
- Dashboard com KPIs, alertas, pipeline e cards mais fáceis de ler.
- Tipografia administrativa aumentada em pontos importantes.
- Filtros organizados como uma barra única.
- Tabelas com cabeçalho fixo, melhor contraste e ações mais claras.
- Cards de propostas, agenda, CRM e configurações refinados.
- Formulários com campos maiores e estados de foco consistentes.
- Melhor visual para alertas, estados vazios, zona de risco e configuração.
- Responsividade do Admin revisada para 960px, 720px e 480px.

## Identidade
- Mantida a paleta ALUNERI/NEXORA em azul, ciano e roxo.
- Nenhuma funcionalidade foi removida.
- Não há mudança de banco de dados ou migration.
