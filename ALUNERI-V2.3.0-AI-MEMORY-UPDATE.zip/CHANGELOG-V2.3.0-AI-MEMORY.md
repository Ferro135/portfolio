# ALUNERI 2.3.0 — AI Memory & Product Discovery

## Memória real da conversa
- O assistente passa a manter um estado estruturado do projeto entre mensagens.
- Objetivo, público, fluxo principal, MVP, integrações, restrições, orçamento, prazo e critério de sucesso ficam separados do texto do chat.
- A memória volta ao modelo em cada turno para evitar perguntas repetidas e perda de contexto.
- Correções feitas pelo visitante atualizam o contexto em vez de reiniciar a descoberta.

## Continuidade no navegador
- Conversa recente e memória do projeto ficam em `sessionStorage` da aba.
- Trocar de página ou recarregar não faz a IA esquecer o projeto.
- `Nova` limpa conversa e memória imediatamente.
- Nada disso entra no CRM sem a confirmação explícita do briefing.

## Qualidade de resposta
- GPT-5.6 Sol continua como padrão.
- Reasoning automático: perguntas simples usam menos esforço; arquitetura, integrações e briefing usam mais.
- Base pública é selecionada por relevância ao assunto e à página atual, reduzindo ruído no prompt.
- A IA não pergunta novamente algo já presente na memória.
- Respostas curtas como “sim”, “3 pessoas”, “WhatsApp” e “os dois” são interpretadas dentro do contexto da pergunta anterior.
- Quando o contexto já é suficiente, a IA deixa de entrevistar e passa a propor escopo/MVP/arquitetura.

## Interface
- Novo cartão “Contexto do projeto” com progresso de entendimento.
- O visitante pode abrir o cartão e conferir o que a IA entendeu: objetivo, usuários, fluxo, MVP e integrações.
- Header do chat mostra a fase atual: Entendendo, Estruturando escopo, Desenhando solução ou Briefing pronto.
- Campo de mensagem agora é multilinha: Enter envia e Shift+Enter quebra linha.
- Sugestões continuam dinâmicas e ligadas à conversa atual.

## Anti-repetição
- Comparação com as últimas quatro respostas.
- Se a primeira geração repetir conteúdo, uma segunda geração recebe instruções de reparo para avançar a conversa.
- O reparo usa a memória do projeto para escolher o próximo ponto ainda não resolvido.

## Privacidade
- Política de Privacidade atualizada para explicar `sessionStorage` temporário.
- Responses API permanece com `store: false`.
